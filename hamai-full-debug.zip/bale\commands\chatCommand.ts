import { askHamAI } from "../../../core/ai/hamaiClient"
import { baleSendMessage } from "../baleService"

export async function handleChat(chatId: number, text: string) {
  const response = await askHamAI(text)

  if (response) {
    await baleSendMessage(chatId, response)
  }
}

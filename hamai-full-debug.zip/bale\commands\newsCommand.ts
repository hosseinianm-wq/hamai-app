import { handleNewsCommand } from "../../../core/news/baleNewsHandler"

export async function handleNews(chatId: number) {
  await handleNewsCommand(chatId)
}
